#!/bin/sh

echo "#!/bin/sh
tar -xf linux-4.15.tar.xz" > unpack-linux
chmod +x unpack-linux


