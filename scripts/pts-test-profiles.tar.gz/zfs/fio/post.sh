#!/bin/sh

cd fio-3.1/
rm -f iometer.0.0
